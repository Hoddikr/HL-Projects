﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HL.FileComparer.Controls
{
    /// <summary>
    /// Represents the results of searching for identical files to the user and allows the user to take action on each file
    /// </summary>
    public class CompareResultsControls : UserControl
    {

    }
}
